// setter injector example 

package com.cg.beans;

import java.util.ArrayList;

public class Employee {
	
	private String firstName;
	private String lastName;
	private int age;
	private String name;
	Department dept;
	
	
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
		
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * 
	 */
	public Employee() {
		dept = new Department();
	
	}
	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", name=" + name
				+ ", dept=" + dept + "]";
	}
	/**
	 * @param firstName
	 * @param lastName
	 * @param age
	 */
	
	
	public Employee(String firstName, String lastName, int age) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public Employee(Department d1) {
		
	}
   public void m1() {
	System.out.println("do some initialization ");
}

	public void m2() {
		System.out.println("clean up bin---------- ");
}	
}
