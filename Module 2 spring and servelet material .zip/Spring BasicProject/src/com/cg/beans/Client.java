package com.cg.beans;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	public static void method(){
		
	}
	
	public static void main(String[] args) {
	// this is creating the object without the new keyword by using bean xml	
	Resource res  = new ClassPathResource("beans.xml");//bean.xml ka path hai
	XmlBeanFactory factory = new XmlBeanFactory (res);
	/*Employee emp = (Employee) factory.getBean("e1");
	
	//This we have define in the bean 
	emp.setFirstName("A");
	emp.setLastName("B");
	emp.setAge(20);
	
	System.out.println(emp);
	*/
	/*UserCredentials user = (UserCredentials) factory.getBean("cred");
	System.out.println(user);*/
	
	Employee user1 = (Employee) factory.getBean("e1");
	Employee user2 = (Employee) factory.getBean("e2");
	System.out.println(user1);
	System.out.println(user2);
}

}
