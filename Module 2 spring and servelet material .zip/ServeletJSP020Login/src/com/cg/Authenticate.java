package com.cg;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Authenticate
 */
@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// pick up query string data(get)
		//pick up form  data(post)
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	RequestDispatcher dispatch = null;
	
	// for multiple data we have String []= request.getParameterValues()
	if (username.equals("aa")&&(password.equals("aa"))) {
		String fullname = "aa aaa  aaaaa";
		
		//Request Scope
		request.setAttribute("fullname", fullname);
		dispatch = request.getRequestDispatcher("/WEB-INF/pages/MainMenu.jsp");
		
	}else {
		request.setAttribute("message", "wrong authentication please do again ");
		dispatch = request.getRequestDispatcher("Login.jsp");
		
		
	}
	dispatch.forward(request, response);
	System.out.println("user name:"+ username);
	
	}

	

}
