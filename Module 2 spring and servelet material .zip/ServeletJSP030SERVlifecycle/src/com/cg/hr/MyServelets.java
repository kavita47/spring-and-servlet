package com.cg.hr;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// this is eager servelet creation.
@WebServlet(urlPatterns="/MyServelets", loadOnStartup = 1)
public class MyServelets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		
		System.out.println("In init(ServeletConfig)");
	}
	/* 
	 * init(Servelet configure ): this is for initialization 
	*Initialization and resourse allocation are done here
	*init(): It is for innitialization overriding.
	*service(): This method is called on every request.
	*destroy(): this method is called while un-deployed the servelet 
	*Resourse deallocation.
	*Eager: created at the time of starting the server consume resources right from 
	*the begining normally used for the servelet which are always used by all user .
	*load on start is positive
	*Home login main menu exaples hai 
	*lazy: created only when first request comes in.
	* Normally used for servelet which may be instantiated optionally.
	* List allEmps, addNewEmps.
	*  Servelet API: 
     
     
*/
	public void destroy() {
		System.out.println("In destroy()");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("In doGet()");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
         
}
